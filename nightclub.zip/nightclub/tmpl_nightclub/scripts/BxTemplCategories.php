<?php

/**
 * Copyright (c) BoonEx Pty Limited - http://www.boonex.com/
 * CC-BY License - http://creativecommons.org/licenses/by/3.0/
 */

require_once(BX_DIRECTORY_PATH_BASE . 'scripts/BxBaseCategories.php');

class BxTemplCategories extends BxBaseCategories
{
    function BxTemplCategories()
    {
        parent::BxBaseCategories();
    }
}
