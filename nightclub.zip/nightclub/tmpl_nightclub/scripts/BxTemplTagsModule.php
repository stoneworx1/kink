<?php

bx_import('BxBaseTagsModule');

class BxTemplTagsModule extends BxBaseTagsModule
{
    function BxTemplTagsModule($aParam, $sTitle, $sUrl)
    {
        parent::BxBaseTagsModule($aParam, $sTitle, $sUrl);
    }
}
