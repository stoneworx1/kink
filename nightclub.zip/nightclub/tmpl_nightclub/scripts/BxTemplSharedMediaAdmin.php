<?php

require_once( BX_DIRECTORY_PATH_BASE . 'scripts/BxBaseSharedMediaAdmin.php' );

class BxTemplSharedMediaAdmin extends BxBaseSharedMediaAdmin
{
    function BxTemplSharedMediaAdmin()
    {
        BxBaseSharedMediaAdmin::BxBaseSharedMediaAdmin();
    }
}
