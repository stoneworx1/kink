<?php

    $sTemplName = 'nightclub';
    $sTemplVer = $GLOBALS['site']['ver'] . '.' . $GLOBALS['site']['build'];
    $sTemplVendor = 'BoonEx';
    $sTemplPreview = 'preview.png';
    $sTemplDesc = _t('_adm_txt_templ_evo_desc');
