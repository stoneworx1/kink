<?php

bx_import('BxBaseCategoriesModule');

class BxTemplCategoriesModule extends BxBaseCategoriesModule
{
    function BxTemplCategoriesModule($aParam, $sTitle, $sUrl)
    {
        parent::BxBaseCategoriesModule($aParam, $sTitle, $sUrl);
    }
}
