<?php

require_once( BX_DIRECTORY_PATH_BASE . 'scripts/BxBaseSearchResultSharedMedia.php' );

class BxTemplSearchResultSharedMedia extends BxBaseSearchResultSharedMedia
{
    function BxTemplSearchResultSharedMedia ($sModuleClass = '')
    {
        parent::BxBaseSearchResultSharedMedia($sModuleClass);
    }
}
