<?php

/**
 * Copyright (c) BoonEx Pty Limited - http://www.boonex.com/
 * CC-BY License - http://creativecommons.org/licenses/by/3.0/
 */

bx_import('BxBaseSocialSharing');

/**
 * @see BxDolSocialSharing
 */
class BxTemplSocialSharing extends BxBaseSocialSharing
{
    function __construct()
    {
        parent::__construct();
    }
}
