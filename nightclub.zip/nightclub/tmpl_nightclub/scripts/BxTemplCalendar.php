<?php

bx_import ('BxBaseCalendar');

/**
 * @see BxDolCalendar
 */
class BxTemplCalendar extends BxBaseCalendar
{
    function BxTemplCalendar($iYear, $iMonth)
    {
        parent::BxBaseCalendar($iYear, $iMonth);
    }
}
