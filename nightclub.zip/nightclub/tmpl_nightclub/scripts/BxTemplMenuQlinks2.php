<?php

require_once( BX_DIRECTORY_PATH_BASE . 'scripts/BxBaseMenuQlinks2.php' );

//customization class for your quick links menus
class BxTemplMenuQlinks2 extends BxBaseMenuQlinks2
{
    function BxTemplMenuQlinks2()
    {
        parent::BxBaseMenuQlinks2();
    }
}
