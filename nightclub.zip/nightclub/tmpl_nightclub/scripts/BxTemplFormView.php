<?php

require_once( BX_DIRECTORY_PATH_ROOT . "templates/base/scripts/BxBaseFormView.php" );

class BxTemplFormView extends BxBaseFormView
{
    function BxTemplFormView($aInfo)
    {
        BxBaseFormView::BxBaseFormView($aInfo);

    }
}
