<?php

require_once( BX_DIRECTORY_PATH_BASE . 'scripts/BxBaseSearchResult.php' );

class BxTemplSearchResult extends BxBaseSearchResult
{
    function BxTemplSearchResult()
    {
        parent::BxBaseSearchResult();
    }
}
