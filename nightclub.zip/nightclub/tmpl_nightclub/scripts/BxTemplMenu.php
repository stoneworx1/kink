<?php

/**
 * Copyright (c) BoonEx Pty Limited - http://www.boonex.com/
 * CC-BY License - http://creativecommons.org/licenses/by/3.0/
 */

bx_import('BxBaseMenu');

/**
* @see BxBaseMenu;
*/
class BxTemplMenu extends BxBaseMenu
{
	var $aProfileOwnerSubmenu;

    /**
    * Class constructor;
    */
    function BxTemplMenu()
    {
        parent::BxBaseMenu();
    }
    function setCustomSubActions(&$aKeys, $sActionsType, $bSubMenuMode = true)
    {
    	parent::setCustomSubActions($aKeys, $sActionsType, $bSubMenuMode);

    	$this->sCustomActions = $GLOBALS['oSysTemplate']->parseHtmlByContent($this->sCustomActions, array(
    		'popup' => $GLOBALS['oFunctions']->transBox(
    			$GLOBALS['oSysTemplate']->parseHtmlByName('share_popup.html', array())
    		)
    	));
    }

    function genSubItems($iTItemID = 0)
    {
    	$sSubItems = parent::genSubItems($iTItemID);
    	if(empty($sSubItems))
    		return '';

    	$iSelected = (int)$this->aMenuInfo['currentCustom'] > 0 ? (int)$this->aMenuInfo['currentCustom'] : $this->getSubItemFirst($this->aMenuInfo['currentTop']);
    	$aSelected = $this->aTopMenu[$iSelected];

    	return $GLOBALS['oSysTemplate']->parseHtmlByName('navigation_menu_sub_header_submenu.html', array(
    		'link' => $aSelected['Link'],
    		'onclick' => 'javascript:return oBxEvoTopMenu.showSubmenuSubmenu(this);',
    		'caption' => _t($aSelected['Caption']),
    		'submenu' => $sSubItems
    	));
    }

    function getSubItemFirst($iTItemID = 0)
    {
    	$iResult = 0;
    	foreach( $this->aTopMenu as $iItemID => $aItem ) {
            if( $aItem['Type'] != 'custom' )
                continue;
            if( $aItem['Parent'] != $iTItemID )
                continue;
            if( !$this->checkToShow( $aItem ) )
                continue;

			$iResult = $iItemID;
			break;
    	}

    	return $iResult;
    }

    function genSubHeaderCaption($aItem, $sCaption, $sTemplateFile = 'navigation_menu_sub_header_caption.html')
    {
    	return '';
    }

    function genSubHeaderLogin($sTemplateFile = 'login_join.html')
    {
    	$sContent = parent::genSubHeaderLogin($sTemplateFile);

    	return $GLOBALS['oSysTemplate']->parseHtmlByContent($sContent, array(
    		'popup' => $GLOBALS['oFunctions']->transBox(
    			$GLOBALS['oSysTemplate']->parseHtmlByName('share_popup.html', array())
    		)
    	)); 
    }

}

// Creating template navigation menu class instance
$oTopMenu = new BxTemplMenu();
