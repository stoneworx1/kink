<?php

/**
 * Copyright (c) BoonEx Pty Limited - http://www.boonex.com/
 * CC-BY License - http://creativecommons.org/licenses/by/3.0/
 */

bx_import ('BxBaseIndexPageView');

class BxTemplIndexPageView extends BxBaseIndexPageView
{
    function BxTemplIndexPageView()
    {
        BxBaseIndexPageView::BxBaseIndexPageView();
    }
}
